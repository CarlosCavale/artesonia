import React from 'react';
import { Users, ShoppingBag, TrendingUp } from 'lucide-react';

export default function Stats() {
  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
          <div className="flex flex-col items-center">
            <Users className="h-12 w-12 text-indigo-600" />
            <p className="mt-2 text-3xl font-extrabold text-gray-900">10K+</p>
            <p className="mt-1 text-lg text-gray-500">Active Influencers</p>
          </div>
          
          <div className="flex flex-col items-center">
            <ShoppingBag className="h-12 w-12 text-indigo-600" />
            <p className="mt-2 text-3xl font-extrabold text-gray-900">50K+</p>
            <p className="mt-1 text-lg text-gray-500">Products Listed</p>
          </div>
          
          <div className="flex flex-col items-center">
            <TrendingUp className="h-12 w-12 text-indigo-600" />
            <p className="mt-2 text-3xl font-extrabold text-gray-900">$2M+</p>
            <p className="mt-1 text-lg text-gray-500">Monthly Sales</p>
          </div>
        </div>
      </div>
    </div>
  );
}