import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import VendorCTA from './components/VendorCTA';
import ProductGrid from './components/ProductGrid';
import Stats from './components/Stats';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <Navbar />
      <Hero />
      <Stats />
      <VendorCTA />
      <ProductGrid />
    </div>
  );
}

export default App;