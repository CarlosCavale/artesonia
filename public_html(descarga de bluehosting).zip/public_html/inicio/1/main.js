document.getElementById("contact-form").addEventListener("submit", async function (event) {
  event.preventDefault();

  const nombre = this.nombre.value;
  const correo = this.correo.value;
  const telefono = this.telefono.value;
  const mensaje = this.mensaje.value;

  const emailBody = `
    <h2>Nuevo mensaje de contacto</h2>
    <table>
      <tr>
        <th>Nombre:</th>
        <td>${nombre}</td>
      </tr>
      <tr>
        <th>Correo electrónico:</th>
        <td>${correo}</td>
      </tr>
      <tr>
        <th>Teléfono:</th>
        <td>${telefono || 'No proporcionado'}</td>
      </tr>
      <tr>
        <th>Mensaje:</th>
        <td>${mensaje}</td>
      </tr>
    </table>
  `;

  // Implementa la función 'sendEmail' en base a tu proveedor de correo electrónico elegido.
  // sendEmail("contacto.carlos.cj@gmail.com", "Nuevo mensaje de contacto", emailBody);
});

function onScroll() {
  const windowHeight = window.innerHeight;
  const scrollY = window.scrollY;

  document.querySelectorAll("section h2").forEach((title) => {
    const rect = title.getBoundingClientRect();
    const top = rect.top + scrollY;

    if (scrollY + windowHeight >= top + rect.height / 2 && scrollY <= top + rect.height) {
      title.style.opacity = "1";
      title.style.transform = "translateY(0)";
    } else {
      title.style.opacity = "0";
      title.style.transform = "translateY(20px)";
    }
  });
}


window.addEventListener("scroll", onScroll);
window.addEventListener("load", onScroll);

function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  const windowHeight = window.innerHeight || document.documentElement.clientHeight;
  return rect.top >= 0 && rect.top <= windowHeight;
}

function checkVisibility() {
  const titles = document.querySelectorAll("h2");
  titles.forEach((title) => {
    if (isInViewport(title)) {
      if (!title.classList.contains("visible")) {
        title.classList.add("visible");
        title.style.animation = "none";
        // Forzar un reflujo (actualización de layout)
        void title.offsetWidth;
        title.style.animation = "fadeIn 1s";
      }
    } else {
      title.classList.remove("visible");
    }
  });
}

window.addEventListener("scroll", checkVisibility);

document.querySelectorAll(".acordeon-item, .audio-acordeon-item").forEach((item) => {
  item.addEventListener("mouseenter", (event) => {
    const rect = item.getBoundingClientRect();
    const mouseY = event.clientY - rect.top;
    item.style.transformOrigin = `center ${mouseY}px`;
  });
});


const subtitulo = document.querySelector("#banner h3");
const subtituloText = subtitulo.innerHTML;
subtitulo.innerHTML = "";

setTimeout(() => {
  let i = 0;
  const timer = setInterval(() => {
    if (i < subtituloText.length) {
      subtitulo.innerHTML += subtituloText.charAt(i);
      i++;
    } else {
      clearInterval(timer);
    }
  }, 100);
}, 1000);

setTimeout(() => {
  subtitulo.style.opacity = "1";
}, 100);





document.querySelectorAll('.acordeon-item, .audio-acordeon-item').forEach((item) => {
  item.addEventListener('touchstart', () => {
    item.classList.add('touched');
  });

  item.addEventListener('touchend', () => {
    item.classList.remove('touched');
  });
});


function toggleTouch(element) {
  if (element.classList.contains('touched')) {
    element.classList.remove('touched');
  } else {
    element.classList.add('touched');
  }
}

document.querySelectorAll('.acordeon-item, .audio-acordeon-item').forEach((item) => {
  item.addEventListener('mouseenter', () => toggleTouch(item));
  item.addEventListener('mouseleave', () => toggleTouch(item));
  item.addEventListener('touchstart', () => toggleTouch(item));
  item.addEventListener('touchend', () => toggleTouch(item));
});


function createMouseEvent(type, touchEvent) {
  const mouseEvent = new MouseEvent(type, {
    bubbles: true,
    cancelable: true,
    view: window,
    screenX: touchEvent.changedTouches[0].screenX,
    screenY: touchEvent.changedTouches[0].screenY,
    clientX: touchEvent.changedTouches[0].clientX,
    clientY: touchEvent.changedTouches[0].clientY,
    button: 0,
  });
  return mouseEvent;
}


document.addEventListener('touchstart', (event) => {
  if (event.touches.length === 1) {
    const mouseEvent = createMouseEvent('mousedown', event);
    event.target.dispatchEvent(mouseEvent);
  }
});

document.addEventListener('touchend', (event) => {
  const mouseEvent = createMouseEvent('mouseup', event);
  event.target.dispatchEvent(mouseEvent);
  const clickEvent = createMouseEvent('click', event);
  event.target.dispatchEvent(clickEvent);
});

document.addEventListener('touchmove', (event) => {
  const mouseEvent = createMouseEvent('mousemove', event);
  event.target.dispatchEvent(mouseEvent);
});



function showDescription(event) {
  const item = event.currentTarget;
  const description = item.querySelector('.descripcion');
  description.style.opacity = '1';
}

function hideDescription(event) {
  const item = event.currentTarget;
  const description = item.querySelector('.descripcion');
  description.style.opacity = '0';
}

document.querySelectorAll('.acordeon-item, .audio-acordeon-item').forEach((item) => {
  // Eventos para dispositivos de escritorio
  item.addEventListener('mouseenter', showDescription);
  item.addEventListener('mouseleave', hideDescription);

  // Eventos táctiles para dispositivos móviles
  item.addEventListener('touchstart', showDescription);
  item.addEventListener('touchend', hideDescription);
});

