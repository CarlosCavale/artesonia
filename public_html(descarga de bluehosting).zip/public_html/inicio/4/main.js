document.getElementById("contact-form").addEventListener("submit", async function (event) {
  event.preventDefault();

  const nombre = this.nombre.value;
  const correo = this.correo.value;
  const telefono = this.telefono.value;
  const mensaje = this.mensaje.value;

  const emailBody = `
    <h2>Nuevo mensaje de contacto</h2>
    <table>
      <tr>
        <th>Nombre:</th>
        <td>${nombre}</td>
      </tr>
      <tr>
        <th>Correo electrónico:</th>
        <td>${correo}</td>
      </tr>
      <tr>
        <th>Teléfono:</th>
        <td>${telefono || 'No proporcionado'}</td>
      </tr>
      <tr>
        <th>Mensaje:</th>
        <td>${mensaje}</td>
      </tr>
    </table>
  `;

  // Implementa la función 'sendEmail' en base a tu proveedor de correo electrónico elegido.
  // sendEmail("contacto.carlos.cj@gmail.com", "Nuevo mensaje de contacto", emailBody);
});

function onScroll() {
  const windowHeight = window.innerHeight;
  const scrollY = window.scrollY;

  document.querySelectorAll("section h2").forEach((title) => {
    const rect = title.getBoundingClientRect();
    const top = rect.top + scrollY;

    if (scrollY + windowHeight >= top + rect.height / 2 && scrollY <= top + rect.height) {
      title.style.opacity = "1";
      title.style.transform = "translateY(0)";
    } else {
      title.style.opacity = "0";
      title.style.transform = "translateY(20px)";
    }
  });
}


window.addEventListener("scroll", onScroll);
window.addEventListener("load", onScroll);

function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  const windowHeight = window.innerHeight || document.documentElement.clientHeight;
  return rect.top >= 0 && rect.top <= windowHeight;
}

function checkVisibility() {
  const titles = document.querySelectorAll("h2");
  titles.forEach((title) => {
    if (isInViewport(title)) {
      if (!title.classList.contains("visible")) {
        title.classList.add("visible");
        title.style.animation = "none";
        // Forzar un reflujo (actualización de layout)
        void title.offsetWidth;
        title.style.animation = "fadeIn 1s";
      }
    } else {
      title.classList.remove("visible");
    }
  });
}

window.addEventListener("scroll", checkVisibility);



document.getElementById("contact-form").addEventListener("submit", async function (event) {
  // ... (resto del código original)
});

function onScroll() {
  // ... (resto del código original)
}

window.addEventListener("scroll", onScroll);
window.addEventListener("load", onScroll);

function isInViewport(element) {
  // ... (resto del código original)
}

function checkVisibility() {
  // ... (resto del código original)
}

window.addEventListener("scroll", checkVisibility);

// ... (resto del código original)

let isDescriptionVisible = false;
let currentItem = null;

function showDescription(event) {
  const item = event.currentTarget;
  const description = item.querySelector('.descripcion');
  description.style.opacity = '1';
}

function hideDescription(event) {
  const item = event.currentTarget;
  const description = item.querySelector('.descripcion');
  description.style.opacity = '0';
}

function toggleDescription(event) {
  const item = event.currentTarget;
  const description = item.querySelector('.descripcion');

  if (isDescriptionVisible && currentItem === item) {
    description.style.opacity = '0';
    isDescriptionVisible = false;
  } else {
    if (currentItem) {
      currentItem.querySelector('.descripcion').style.opacity = '0';
    }
    description.style.opacity = '1';
    isDescriptionVisible = true;
    currentItem = item;
  }
}

function hideDescriptionOnOutsideTouch(event) {
  if (!currentItem) return;

  if (!currentItem.contains(event.target)) {
    currentItem.querySelector('.descripcion').style.opacity = '0';
    isDescriptionVisible = false;
    currentItem = null;
  }
}

document.querySelectorAll(".acordeon-item, .audio-acordeon-item").forEach((item) => {
  item.addEventListener("mouseenter", showDescription);
  item.addEventListener("mouseleave", hideDescription);
  item.addEventListener("touchstart", toggleDescription);
});

document.addEventListener("touchstart", hideDescriptionOnOutsideTouch);

// ... (resto del código original)



const subtitulo = document.querySelector("#banner h3");
const subtituloText = subtitulo.innerHTML;
subtitulo.innerHTML = "";

setTimeout(() => {
  let i = 0;
  const timer = setInterval(() => {
    if (i < subtituloText.length) {
      subtitulo.innerHTML += subtituloText.charAt(i);
      i++;
    } else {
      clearInterval(timer);
    }
  }, 100);
}, 1000);

setTimeout(() => {
  subtitulo.style.opacity = "1";
}, 100);

