<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $mensaje = $_POST["mensaje"];
    $destinatario = "tu_correo@ejemplo.com"; // Reemplaza esto con tu correo electrónico

    $asunto = "Nuevo mensaje de contacto";
    $contenido = "
        <h2>Nuevo mensaje de contacto</h2>
        <table>
            <tr>
                <th>Nombre:</th>
                <td>$nombre</td>
            </tr>
            <tr>
                <th>Correo electrónico:</th>
                <td>$correo</td>
            </tr>
            <tr>
                <th>Teléfono:</th>
                <td>" . ($telefono ?: 'No proporcionado') . "</td>
            </tr>
            <tr>
                <th>Mensaje:</th>
                <td>$mensaje</td>
            </tr>
        </table>
    ";

    $cabeceras  = "MIME-Version: 1.0\r\n";
    $cabeceras .= "Content-type: text/html; charset=UTF-8\r\n";
    $cabeceras .= "From: $correo\r\n";

    if (mail($destinatario, $asunto, $contenido, $cabeceras)) {
        echo "Correo enviado correctamente";
    } else {
        echo "Error al enviar el correo";
    }
} else {
    echo "Método no permitido";
}
?>
